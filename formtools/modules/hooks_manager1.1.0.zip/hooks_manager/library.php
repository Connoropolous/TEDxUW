<?php

$folder = dirname(__FILE__);
require_once("$folder/global/code/module.php");
require_once("$folder/global/code/rules.php");