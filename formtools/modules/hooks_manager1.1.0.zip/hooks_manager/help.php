<?php

require("../../global/library.php");
$folder = dirname(__FILE__);
require_once("$folder/library.php");
ft_init_module_page();

ft_display_module_page("templates/help.tpl");